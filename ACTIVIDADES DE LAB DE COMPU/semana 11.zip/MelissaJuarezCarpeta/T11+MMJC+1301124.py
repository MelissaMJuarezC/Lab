# Encabezado
print("Nombre: Melissa María Juárez Cru")
print("Número de carné: 1301124")

# Método para calcular la serie (1/1) + (1/2) + (1/3) + ... + (1 / N)
def calcular_serie_1(N):
    suma = 0
    for i in range(1, N+1):
        suma += 1/i
    return suma

# Método para calcular la serie (1/2^1) + (1 / 2^2) + (1 / 2^3) + ... + (1 / 2^N)
def calcular_serie_2(x, a, n):
    suma = 0
    for i in range(1, n+1):
        suma += (x ** a) / i
    return suma

# Método para calcular la serie с. Ex=ох"а"-к
def calcular_serie_3(x, a, n):
    suma = 0
    for i in range(1, n+1):
        suma += (x ** (a - i))
    return suma

# Función principal
def main():
    # Solicitar entrada al usuario y validarla
    N = int(input("Ingrese un número entero mayor a 0 para la serie 1: "))
    while N <= 0:
        N = int(input("Por favor, ingrese un número entero mayor a 0: "))

    # Calcular y mostrar resultados
    print("Serie 1:", calcular_serie_1(N))

    # Solicitar más entradas al usuario
    x = int(input("Ingrese el valor de 'x' para la serie 2: "))
    a = int(input("Ingrese el valor de 'a' para la serie 2: "))
    n = int(input("Ingrese el valor de 'n' para la serie 2: "))

    # Mostrar resultados para la serie 2
    print("Serie 2:", calcular_serie_2(x, a, n))

    # Solicitar más entradas al usuario
    x = int(input("Ingrese el valor de 'x' para la serie 3: "))
    a = int(input("Ingrese el valor de 'a' para la serie 3: "))
    n = int(input("Ingrese el valor de 'n' para la serie 3: "))

    # Mostrar resultados para la serie 3
    print("Serie 3:", calcular_serie_3(x, a, n))

# Llamar a la función principal
if __name__== "_main_":
    main()
