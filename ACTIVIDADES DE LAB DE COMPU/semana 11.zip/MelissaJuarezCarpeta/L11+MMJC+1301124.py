print("Semana No. 11: Ejercicio 1")
N=int(input("Ingrese un numero mayor que 0"))
if N<=0:
   print("Ingrese un numero mayor a 0")
print()
A=0
B=1
C=0
i=2
resultados=""
reultado=str(A)
if N>1:
    resultados+=(","+str(B))
    while i<N:
        C=A+B
        resultados+=(","+str(C))
        A=B
        B=C
        i=i+1
        print(resultados)
    else:
        print(resultados)
